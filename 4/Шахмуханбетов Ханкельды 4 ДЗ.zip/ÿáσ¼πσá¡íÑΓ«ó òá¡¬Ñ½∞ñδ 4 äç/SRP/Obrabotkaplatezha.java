package SRP;

public class Obrabotkaplatezha {
    public void processPayment(String paymentdetails){
        System.out.println("Process ispolzuetsya na " + paymentdetails);
    }
}
