package SRP;

public class Uvedomlenie {
    public void sendconfirmationemail(String email){
        System.out.println("Otpravleno na " + email);
    }
}
