package ISP;

public interface IFax{
    void fax(String content);
}
