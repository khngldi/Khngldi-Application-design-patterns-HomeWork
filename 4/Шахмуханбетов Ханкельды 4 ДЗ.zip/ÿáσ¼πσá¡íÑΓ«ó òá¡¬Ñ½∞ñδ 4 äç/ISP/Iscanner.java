package ISP;

public interface Iscanner{
    void scan(String content);
}
