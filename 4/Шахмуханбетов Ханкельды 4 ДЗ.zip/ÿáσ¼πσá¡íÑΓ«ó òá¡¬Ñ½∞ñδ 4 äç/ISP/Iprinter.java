package ISP;

public interface Iprinter {
    void print(String content);
}
