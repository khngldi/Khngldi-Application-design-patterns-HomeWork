package DIP;

public interface NotificationSender {
    void send(String message);
}
